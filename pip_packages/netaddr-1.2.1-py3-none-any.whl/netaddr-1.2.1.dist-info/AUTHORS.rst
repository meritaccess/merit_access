- David P. D. Moss (author, maintainer) drkjam@gmail.com
- Stefan Nordhausen (maintainer) stefan.nordhausen@immobilienscout24.de
- Jakub Stasiak (maintainer) jakub@stasiak.at

Released under the BSD License (see :doc:`license` for details).
